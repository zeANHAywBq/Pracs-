<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Calculator</title>
</head>
<body>
<?php 
   if(isset($_GET['num1']) && isset($_GET['num2'] )&& isset($_GET['operation']))
   {
       $num1 = $_GET['num1'];
       $num2 = $_GET['num2'];
       $operation = $_GET['operation'];
       ?>
       <form action="index.php" method="GET">
       <label for="Number 1">Number 1</label>
       <input type="number" name="num1" value='<?php echo $num1; ?>'>
       <label for="Number 1">Number 2</label>
       <input type="number" name="num2" value='<?php echo $num2; ?>'>
       <label for="Number 1">Result</label>
        <?php 
        if($operation=='add')
        {
            ?>
       <input type="number" disabled value='<?php echo $num1+$num2; ?>'>
        <?php
        }
        else if($operation =='sub')
        {
            ?>
            <input type="number" disabled value='<?php echo $num1-$num2; ?>'>
             <?php
        }
        else if($operation =='mul')
        {
            ?>
            <input type="number" disabled value='<?php echo $num1*$num2; ?>'>
             <?php
        }
        else if($operation =='div')
        {
            ?>
            <input type="number" disabled value='<?php echo $num1/$num2; ?>'>
             <?php
        }
        else if($operation =='mod')
        {
            ?>
            <input type="number" disabled value='<?php echo $num1%$num2; ?>'>
             <?php
        }
        ?>
        <br/>
        <br/>
        <br/>
        <input type="submit" value="add" name="operation">

        <input type="submit" value="sub" name="operation">
        <input type="submit" value="mul" name="operation">
        <input type="submit" value="div" name="operation">
        <input type="submit" value="mod" name="operation">

        </form>
<?php 
   }
   else 
   {
       ?>
    <form action="index.php" method="GET">
    <label for="Number 1">Number 1</label>
    <input type="number" name="num1" value=''>
    <label for="Number 1">Number 2</label>
    <input type="number" name="num2" value=''>
    <label for="Number 1">Result</label>
    <input type="number" disabled value=''>
    <br/>
        <br/>
        <br/>
        <input type="submit" value="add" name="operation">

        <input type="submit" value="sub" name="operation">
        <input type="submit" value="mul" name="operation">
        <input type="submit" value="div" name="operation">
        <input type="submit" value="mod" name="operation">
        </form>
    <?php 
   }
   ?>
</body>
</html>