<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta http-equiv="X-UA-Compatible" content="ie=edge" />
    <title>Tunuk Tunuk Tun</title>
  </head>
  <body>
    <?php
      if(isset($_GET['submit']))
      {
        echo "<script>alert('Form submitted successfully');</script>";

      }
      ?>
    <form id="form">
      <label>Name</label>
      <input type="text" name="name" id="name" required />
      <br />
      <br />
      <label>Age</label>
      <input type="number" name="age" id="required" min="18" required />
      <br />
      <br />
      <label>Course Id</label>
      <input type="number" name="courseid" id="required" required />
      <br />
      <br />
      <label>Email Id</label>

      <input type="email" name="email" id="required" required />
      <br />
      <br />
      <label>Address </label>
      <input type="text" name="Address" id="name" required />
      <br />
      <br />
      <label>Mobile No</label>

      <input type="tel" name="mobileno" id="required" required />
      <br />
      <br />
      <label>Course Name </label>
      <input type="text" name="coursename" id="name" required />
      <br />
      <br />
      <input type="submit" name="submit" id=""  />
    </form>
  </body>
</html>
